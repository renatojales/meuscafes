<?php
abstract class DB {
   protected $db;
   public function __construct($db) {
       $this->db = $db;
   }
}
